/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package Property_CRUD;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author anamikaverma
 */
public class View_Properties extends javax.swing.JPanel {

    /**
     * Creates new form Add_Property
     */
    public View_Properties() {
        initComponents();
        showdata();
    }

    
    Connection Con = null;
    Statement St = null;
    ResultSet Rs = null;
    
    public void showdata(){
        try{
            Con = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=Project-DAMG;encrypt=true;trustServerCertificate=true","SA","Boston@123");
            PreparedStatement show= Con.prepareStatement("select * from Property");
            
            ResultSet Rs = show.executeQuery();
            ResultSetMetaData rsmd = Rs.getMetaData();
            DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
            model.setRowCount(0);
            int cols = rsmd.getColumnCount();
            String [] colName = new String[cols];
            String pID,oID,address,city,state,zip,county,type;
            while (Rs.next()){
                pID=Rs.getString(1);
                oID=Rs.getString(2);
                address = Rs.getString(3);
                city = Rs.getString(4);
                state = Rs.getString(5);
                zip = Rs.getString(6);
                county = Rs.getString(7);
                type = Rs.getString(8);
                String[] row = {pID,oID,address,city,state,zip,county,type};
                model.addRow(row);
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jButton2 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel3 = new javax.swing.JLabel();

        setBackground(new java.awt.Color(255, 255, 255));
        setPreferredSize(new java.awt.Dimension(681, 600));
        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Bodoni 72", 1, 36)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("View Property Listing");
        add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 16, 681, 33));

        jLabel2.setFont(new java.awt.Font("Bodoni 72", 1, 18)); // NOI18N
        jLabel2.setText("Search with Owner ID");
        add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(118, 112, -1, -1));
        add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(318, 106, 214, -1));

        jButton2.setFont(new java.awt.Font("Bodoni 72", 1, 18)); // NOI18N
        jButton2.setText("View");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(151, 141, 158, -1));

        jButton4.setFont(new java.awt.Font("Bodoni 72", 1, 18)); // NOI18N
        jButton4.setText("Refresh");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(352, 141, 158, -1));

        jTable1.setFont(new java.awt.Font("Bodoni 72", 0, 14)); // NOI18N
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Property_ID", "Owner ID", "Address", "City", "State", "Zipcode", "County", "Property Type"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, true, true, true, true, true, true, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

        add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 210, 620, 350));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/12 img (1).jpeg"))); // NOI18N
        add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(2, -3, 680, 600));
    }// </editor-fold>//GEN-END:initComponents

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        jTextField1.setText("");
        showdata();
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        String id = jTextField1.getText();
        try{
            Con = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=Project-DAMG;encrypt=true;trustServerCertificate=true","SA","Boston@123");
            PreparedStatement show= Con.prepareStatement("select * from Property where Owner_ID = ?");
            show.setString(1, id);
            ResultSet Rs = show.executeQuery();
            ResultSetMetaData rsmd = Rs.getMetaData();
            DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
            model.setRowCount(0);
            int cols = rsmd.getColumnCount();
            String [] colName = new String[cols];
            String pID,oID,address,city,state,zip,county,type;
            while (Rs.next()){
                pID=Rs.getString(1);
                oID=Rs.getString(2);
                address = Rs.getString(3);
                city = Rs.getString(4);
                state = Rs.getString(5);
                zip = Rs.getString(6);
                county = Rs.getString(7);
                type = Rs.getString(8);
                String[] row = {pID,oID,address,city,state,zip,county,type};
                model.addRow(row);
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }//GEN-LAST:event_jButton2ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    // End of variables declaration//GEN-END:variables
}
