/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package Property_CRUD;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *
 * @author anamikaverma
 */
public class Add_Property extends javax.swing.JPanel {

    /**
     * Creates new form Add_Property
     */
    public Add_Property() {
        initComponents();
    }

    Connection Con = null;
    Statement St = null;
    ResultSet Rs = null;
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jTextField3 = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jTextField4 = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jTextField5 = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jTextField6 = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        jButton1 = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();

        setBackground(new java.awt.Color(255, 255, 255));
        setPreferredSize(new java.awt.Dimension(681, 600));
        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Bodoni 72", 1, 36)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("New Property Listing");
        add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 20, 681, 33));

        jLabel2.setFont(new java.awt.Font("Bodoni 72", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Owner ID");
        add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(151, 116, -1, -1));
        add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(308, 113, 214, -1));

        jLabel3.setFont(new java.awt.Font("Bodoni 72", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Address");
        add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(156, 157, -1, -1));
        add(jTextField2, new org.netbeans.lib.awtextra.AbsoluteConstraints(308, 154, 214, -1));

        jLabel4.setFont(new java.awt.Font("Bodoni 72", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("City");
        add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(182, 198, -1, -1));
        add(jTextField3, new org.netbeans.lib.awtextra.AbsoluteConstraints(308, 195, 214, -1));

        jLabel5.setFont(new java.awt.Font("Bodoni 72", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("State");
        add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(175, 239, -1, -1));
        add(jTextField4, new org.netbeans.lib.awtextra.AbsoluteConstraints(308, 236, 214, -1));

        jLabel6.setFont(new java.awt.Font("Bodoni 72", 1, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Zipcode");
        add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(157, 288, -1, -1));
        add(jTextField5, new org.netbeans.lib.awtextra.AbsoluteConstraints(308, 285, 214, -1));

        jLabel7.setFont(new java.awt.Font("Bodoni 72", 1, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("County");
        add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(164, 329, -1, -1));
        add(jTextField6, new org.netbeans.lib.awtextra.AbsoluteConstraints(308, 326, 214, -1));

        jLabel8.setFont(new java.awt.Font("Bodoni 72", 1, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Property Type");
        add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(123, 370, -1, -1));

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select", "Rental", "Sale" }));
        add(jComboBox1, new org.netbeans.lib.awtextra.AbsoluteConstraints(308, 367, 214, -1));

        jButton1.setFont(new java.awt.Font("Bodoni 72", 1, 18)); // NOI18N
        jButton1.setText("Add Property");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 440, 158, -1));

        jLabel9.setFont(new java.awt.Font("Bodoni 72", 1, 18)); // NOI18N
        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/12 img (1).jpeg"))); // NOI18N
        jLabel9.setPreferredSize(new java.awt.Dimension(680, 600));
        add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 680, 600));
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        try{
            Con = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=Project-DAMG;encrypt=true;trustServerCertificate=true","SA","Boston@123");
            PreparedStatement add= Con.prepareStatement("insert into Property(Owner_ID,Address,City,State,Zipcode,County,PropertyType) values(?,?,?,?,?,?,?)");
            add.setString(1, jTextField1.getText());
            add.setString(2, jTextField2.getText());
            add.setString(3,jTextField3.getText());
            add.setString(4,jTextField4.getText());
            add.setString(5,jTextField5.getText());
            add.setString(6,jTextField6.getText());
            add.setString(7,jComboBox1.getSelectedItem().toString());
            int row=add.executeUpdate();
            //showdata()
            JOptionPane.showMessageDialog(this, "Property is listed successfully!");
            jTextField1.setText("");
            jTextField2.setText("");
            jTextField3.setText("");
            jTextField4.setText("");
            jTextField5.setText("");
            jTextField6.setText("");
            jComboBox1.setSelectedIndex(-1);
            
            Con.close();
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }//GEN-LAST:event_jButton1ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField6;
    // End of variables declaration//GEN-END:variables
}
